(function(window, undefined) {
  var dictionary = {
    "992364ec-1c93-48be-b7ac-ef5cf0fe53b7": "plan3",
    "180d6c82-4307-499b-9fa6-59a0c093e149": "plan2",
    "5fb882f3-3e4a-449b-bdc3-a44c038fd9b1": "infocarro",
    "e63c4181-f0ca-4715-b4c2-7ff9a84caba8": "taquila",
    "843e2122-035b-47b5-9daf-d010d8c161fe": "plan1",
    "b9a257c2-d168-47aa-b301-be0fad11bd84": "agregadoinfocarro",
    "a431361e-3f56-48d4-baa7-4e6c6b3ffb0f": "agregadocita",
    "4fdf0a79-4b1a-4179-9854-91f72ac6aa4a": "calculacostoparqueadero",
    "5e09fca4-785c-46b4-aeb0-2781954d49f0": "plan2taquilla",
    "6c4ee913-43e3-4528-972e-7f7e3f30f977": "Planes",
    "25be49b3-1262-42d5-9425-6735819d9f53": "plan2taquillac",
    "e7b60089-531a-47f3-b6ae-e4d03dddbdb8": "temp",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Screen 1",
    "e79826aa-6e65-488c-85e8-109c4840801e": "pendientes",
    "9fcc8bba-5132-404c-bdda-dc1521a6b4f0": "compra",
    "fe7a5fb6-7778-4dd0-b31b-851af3836528": "compra realizada",
    "109693ac-f6b8-4187-a38d-95cae67d620b": "plan3taquillac",
    "8f155e5a-325f-479f-a4f6-6175188b05a3": "hparqueadero",
    "1fae71ac-3418-4806-b5d2-d4893cafddb0": "infopendientes",
    "dabdf604-c8c0-481d-a844-ecf951b398b6": "añadiranimal",
    "28e3bad6-c09b-4de3-9725-9db957beb617": "buscar",
    "a11708ef-81ce-448b-84fa-900415affbbd": "hagregaranimal",
    "8f7d7c13-0d1e-457b-9f80-fb9ed391f660": "revisarcitas",
    "b4e1bb1a-0834-424c-930e-9a8519f0cc9a": "plan3taquilla",
    "deb0f525-5424-46a7-ac7a-9051720dd9e9": "Animal",
    "9a4b1c0a-bd59-4a44-828b-5f5f724130a2": "login",
    "afbbe6ab-68ec-441f-a9eb-ae18a6b51d2c": "plan1compra",
    "3c5eaa5f-d637-4e9c-b696-03dcafdfc750": "plan3compra",
    "afa4c78e-6ff0-41b1-9bec-ba4689e04236": "plan2compra",
    "0106aa0c-49a6-4255-9e1a-c90b84bdfa2a": "agregarinfocarro",
    "0a0d0685-03ff-4d9e-be6b-28146bc8903b": "plan1taquilla",
    "ecf1f1de-d32b-45a6-a378-329f51025402": "perfil",
    "cfd7ef91-a6e1-441f-9f36-a831e12f7777": "agregadoanimal",
    "3b2be186-f8c7-4577-9ba0-3d7c0ce9de62": "plan1taquillac",
    "5d6b6e5c-a0ed-46c1-b5e2-86ee5790000f": "agregarcita",
    "0abe073a-36d8-4e3c-9295-a008d2cab76b": "mirarautos",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);