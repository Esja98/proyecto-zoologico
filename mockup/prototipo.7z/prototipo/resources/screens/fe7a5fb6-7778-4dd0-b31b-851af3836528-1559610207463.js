jQuery("#simulation")
  .on("click", ".s-fe7a5fb6-7778-4dd0-b31b-851af3836528 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Label_18")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_18 span": {
                      "attributes": {
                        "color": "#6200EE"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_20 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  },{
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_19 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Label_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_19 span": {
                      "attributes": {
                        "color": "#6200EE"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_20 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  },{
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_18 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6c4ee913-43e3-4528-972e-7f7e3f30f977"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Label_20")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_20 span": {
                      "attributes": {
                        "color": "#6200EE"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_19 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  },{
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_18 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Label_21")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_21 span": {
                      "attributes": {
                        "color": "#6200EE"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_20 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  },{
                    "#s-fe7a5fb6-7778-4dd0-b31b-851af3836528 #s-Label_19 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/28e3bad6-c09b-4de3-9725-9db957beb617"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/e7b60089-531a-47f3-b6ae-e4d03dddbdb8"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/ecf1f1de-d32b-45a6-a378-329f51025402"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });