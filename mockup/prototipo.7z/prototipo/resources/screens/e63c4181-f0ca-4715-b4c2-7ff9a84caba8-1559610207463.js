jQuery("#simulation")
  .on("click", ".s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Label_18")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_18 span": {
                      "attributes": {
                        "color": "#6200EE"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_20 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  },{
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_19 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Label_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_19 span": {
                      "attributes": {
                        "color": "#6200EE"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_20 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  },{
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_18 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6c4ee913-43e3-4528-972e-7f7e3f30f977"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Label_20")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_20 span": {
                      "attributes": {
                        "color": "#6200EE"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_19 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  },{
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_18 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Label_21")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_21 span": {
                      "attributes": {
                        "color": "#6200EE"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_20 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  },{
                    "#s-e63c4181-f0ca-4715-b4c2-7ff9a84caba8 #s-Label_19 span": {
                      "attributes": {
                        "color": "#BCBCBC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/28e3bad6-c09b-4de3-9725-9db957beb617"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0a0d0685-03ff-4d9e-be6b-28146bc8903b"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/5e09fca4-785c-46b4-aeb0-2781954d49f0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/b4e1bb1a-0834-424c-930e-9a8519f0cc9a"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/e7b60089-531a-47f3-b6ae-e4d03dddbdb8"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/e63c4181-f0ca-4715-b4c2-7ff9a84caba8"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });